#include <iostream>
#include<string>
using namespace std;
string n="Fisrt" ;
class Quadratic {
private:
    double a, b, c; 

public:

    Quadratic() : a(), b(), c() {}//overload 空值
    Quadratic(double a, double b, double c) : a(a), b(b), c(c) {}//繼承a,b,c之值


    Quadratic operator+(Quadratic &num){ //member operater
        return Quadratic(a + num.a, b + num.b, c + num.c);
    }
    friend ostream& operator<<(ostream &output, Quadratic &num) {
        output << num.a << "x^2 + " << num.b << "x + " << num.c;
        return output;
    }

    friend istream& operator>>(istream &input_num, Quadratic &num) {//operater >> and << should be friend
        cout << "The "<<n<<" polyn0mial a, b, c 's value: ";
        input_num >> num.a >> num.b >> num.c;
        n="second";
        return input_num;

    }
};

int main() {
    Quadratic q1, q2, q3;

    // input 
    cin >> q1;
    cin >> q2;

    //add
    q3 = q1 + q2;

    cout << "Sum of polyn0mials: " << q3 << endl;

    return 0;
}
